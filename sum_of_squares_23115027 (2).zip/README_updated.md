
# Factorial Compiler with Custom Instruction

This project implements a Python-based compiler that calculates the factorial of an input number using all major compiler phases.

## Features

- Lexical Analysis
- Syntax Analysis
- Intermediate Code Generation (Three Address Code - TAC)
- Code Optimization
- Custom Instruction: `FACTORIAL`
- Assembly-like Code Generation
- Final Execution

## Input Format

Enter a single integer value when prompted.

## How to Run

```bash
python main.py
```

## Example

**Input:**
```
5
```

**Output:**
```
Tokens: ['NUMBER']
Parse Tree: FACTORIAL(5)
Three Address Code:
t1 = FACTORIAL 5
Optimized Instruction:
FACTORIAL 5
Assembly Code:
LOAD R1, 5
FACTORIAL R1, R2
PRINT R2
Result: 120
```

## GitHub Link

[GitHub Repository](https://github.com/example/factorial_compiler)
