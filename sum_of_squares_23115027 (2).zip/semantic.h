#pragma once
#include <vector>

bool semanticCheck(const std::vector<int>& tokens);
