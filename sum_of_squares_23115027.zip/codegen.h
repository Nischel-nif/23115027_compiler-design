#pragma once
#include <string>

int computeSumOfSquares(int a, int b);
std::string generateAssemblyCode(int a, int b);
