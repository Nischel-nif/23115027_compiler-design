#pragma once
#include <vector>
#include <string>

std::vector<int> lexer(const std::string& input);
