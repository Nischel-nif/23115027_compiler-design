#include "codegen.h"

std::string generateAssemblyCode(int a, int b) {
    return "MOV R1, " + std::to_string(a) + "\n" +
           "MUL R1, R1\n" +
           "MOV R2, " + std::to_string(b) + "\n" +
           "MUL R2, R2\n" +
           "ADD R3, R1, R2";
}

int computeSumOfSquares(int a, int b) {
    return a * a + b * b;
}
