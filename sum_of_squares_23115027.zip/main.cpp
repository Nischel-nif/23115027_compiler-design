#include <iostream>
#include "lexer.h"
#include "parser.h"
#include "semantic.h"
#include "ir.h"
#include "codegen.h"

int main() {
    std::cout << "Enter two integers: ";
    std::string input;
    std::getline(std::cin, input);

    auto tokens = lexer(input);
    if (!parseTokens(tokens)) {
        std::cerr << "Syntax Error: Expected exactly two integers." << std::endl;
        return 1;
    }
    if (!semanticCheck(tokens)) {
        std::cerr << "Semantic Error: Negative numbers not allowed." << std::endl;
        return 1;
    }

    std::cout << "Tokens: [" << tokens[0] << ", " << tokens[1] << "]\n";

    std::string tac = generateThreeAddressCode(tokens[0], tokens[1]);
    std::cout << "Three-Address Code:\n" << tac << "\n";

    std::string asmCode = generateAssemblyCode(tokens[0], tokens[1]);
    std::cout << "Assembly Code:\n" << asmCode << "\n";

    int result = computeSumOfSquares(tokens[0], tokens[1]);
    std::cout << "Result: " << result << std::endl;

    return 0;
}
